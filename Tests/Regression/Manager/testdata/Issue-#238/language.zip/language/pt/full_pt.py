# Sample python variables file
primeira= "Primeira"
segunda= 2
