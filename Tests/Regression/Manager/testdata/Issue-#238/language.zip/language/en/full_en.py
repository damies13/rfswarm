# Sample python variables file
first = "First"
second = 2

